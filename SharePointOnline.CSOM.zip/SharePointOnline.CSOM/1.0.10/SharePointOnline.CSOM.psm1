<#
  .SYNOPSIS
  Adds the SharePoint Online CSOM DLLs to the PowerShell session. 
  .DESCRIPTION
  Adds the following SharePoint Online CSOM DLLs to the PowerShell session: 
  Microsoft.SharePoint.Client.dll, 
  Microsoft.SharePoint.Client.Publishing.dll, 
  Microsoft.SharePoint.Client.Runtime.dll, 
  Microsoft.SharePoint.Client.Search.dll" 
  .EXAMPLE
  Load-SPOnlineCSOMAssemblies
  #>

function Load-SPOnlineCSOMAssemblies
{
    Load-SPOnlineCSOMAssembly "Microsoft.SharePoint.Client.dll"
    Load-SPOnlineCSOMAssembly "Microsoft.SharePoint.Client.Publishing.dll"
    Load-SPOnlineCSOMAssembly "Microsoft.SharePoint.Client.Runtime.dll"
    Load-SPOnlineCSOMAssembly "Microsoft.SharePoint.Client.Search.dll"
}

<#
  .SYNOPSIS
  Adds a SharePoint Online CSOM DLLs to the PowerShell session. 
  .DESCRIPTION
  Adds a SharePoint Online CSOM DLLs to the PowerShell session. Available DLLs: 
  Microsoft.Office.Client.Policy.dll, 
  Microsoft.Office.Client.TranslationServices.dll, 
  Microsoft.Office.SharePoint.Tools.dll, 
  Microsoft.Online.SharePoint.Client.Tenant.dll, 
  Microsoft.ProjectServer.Client.dll, 
  Microsoft.SharePoint.Client.dll, 
  Microsoft.SharePoint.Client.DocumentManagement.dll, 
  Microsoft.SharePoint.Client.Publishing.dll, 
  Microsoft.SharePoint.Client.Runtime.dll, 
  Microsoft.SharePoint.Client.Search.Applications.dll, 
  Microsoft.SharePoint.Client.Search.dll, 
  Microsoft.SharePoint.Client.Taxonomy.dll, 
  Microsoft.SharePoint.Client.UserProfiles.dll, 
  Microsoft.SharePoint.Client.WorkflowServices.dll
  .EXAMPLE
  Load-SPOnlineCSOMAssembly "Microsoft.SharePoint.Client.UserProfiles.dll"
  .EXAMPLE
  Load-SPOnlineCSOMAssembly -assemblyName "Microsoft.SharePoint.Client.UserProfiles.dll"
  #>
function Load-SPOnlineCSOMAssembly
{
    
	[CmdletBinding()]
	param
    (
	    [parameter(Mandatory=$true, Position=0)]
	    [String]$assemblyName 
	)

    if($assemblyName.ToLower().StartsWith("microsoft.") -and $assemblyName.ToLower().EndsWith(".dll")){
        try
        {
            Add-Type -Path "$PSScriptRoot\$assemblyName"
        }
        catch{            
            throw "Cannot load assembly '$assemblyName'. $($_.Exception.Message)"
        }
    }
    else{
        throw "invalid assembly name '$assemblyName'"
    }
}